#!/usr/bin/env python3
"""
iam_audit.py — Run an AWS IAM security audit and generate JSON/CSV/HTML reports.

Usage:
    python iam_audit.py [--profile PROFILE] [--region REGION] [--output-dir DIR]
                         [--max-key-age DAYS] [--max-unused-days DAYS]

Requires AWS credentials with read-only IAM permissions. See
infrastructure/terraform/ for a least-privilege audit role you can provision.
"""
import argparse
import sys
from pathlib import Path

import boto3

import checks
import report


def run_audit(iam_client, max_key_age: int, max_unused_days: int):
    print("Fetching credential report...")
    cred_report = checks.get_credential_report(iam_client)

    findings = []

    print("Checking root account...")
    findings.append(checks.check_root_mfa(iam_client))
    findings.append(checks.check_root_access_keys(cred_report))
    findings.append(checks.check_root_recent_usage(cred_report))

    print("Checking account password policy...")
    findings.extend(checks.check_password_policy(iam_client))

    print("Checking user MFA status...")
    findings.extend(checks.check_users_mfa(cred_report))

    print("Checking access key rotation...")
    findings.extend(checks.check_access_key_rotation(cred_report, max_key_age))

    print("Checking for unused credentials...")
    findings.extend(checks.check_unused_credentials(cred_report, max_unused_days))

    print("Checking policy attachments...")
    findings.extend(checks.check_no_inline_or_direct_admin_policies(iam_client))

    return findings


def main():
    parser = argparse.ArgumentParser(description="AWS IAM Security Audit")
    parser.add_argument("--profile", default=None, help="AWS CLI profile to use")
    parser.add_argument("--region", default="us-east-1", help="AWS region (IAM is global, but a region is required by boto3)")
    parser.add_argument("--output-dir", default="./reports", help="Directory to write reports into")
    parser.add_argument("--max-key-age", type=int, default=90, help="Max access key age in days before flagging")
    parser.add_argument("--max-unused-days", type=int, default=90, help="Max days of inactivity before flagging a credential as unused")
    parser.add_argument("--fail-on-critical", action="store_true", help="Exit with a non-zero status if any CRITICAL check fails (useful in CI)")
    args = parser.parse_args()

    session = boto3.Session(profile_name=args.profile, region_name=args.region)
    iam_client = session.client("iam")

    try:
        account_id = session.client("sts").get_caller_identity()["Account"]
    except Exception as e:
        print(f"Failed to authenticate with AWS: {e}", file=sys.stderr)
        sys.exit(1)

    findings = run_audit(iam_client, args.max_key_age, args.max_unused_days)

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    report.write_json(findings, out_dir / "iam-audit-report.json")
    report.write_csv(findings, out_dir / "iam-audit-report.csv")
    report.write_html(findings, out_dir / "iam-audit-report.html", account_label=f"Account {account_id}")

    summary = report.summarize(findings)
    print("\n=== IAM Security Audit Summary ===")
    print(f"Account:        {account_id}")
    print(f"Total checks:   {summary['total_checks']}")
    print(f"Passed:         {summary['passed']}")
    print(f"Failed:         {summary['failed']}")
    for sev, count in summary["failed_by_severity"].items():
        print(f"  {sev}: {count}")
    print(f"\nReports written to: {out_dir.resolve()}")

    if args.fail_on_critical and summary["failed_by_severity"].get("CRITICAL", 0) > 0:
        print("\n❌ CRITICAL findings detected — failing the build.", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
