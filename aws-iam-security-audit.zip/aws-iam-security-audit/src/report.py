"""
report.py — Turns a list of Finding objects into JSON, CSV, and a styled
standalone HTML report.
"""
import csv
import json
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import List

from checks import Finding

SEVERITY_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
SEVERITY_COLOR = {
    "CRITICAL": "#ff4d4f",
    "HIGH": "#ff9900",
    "MEDIUM": "#f5c518",
    "LOW": "#38bdf8",
    "INFO": "#9ca3af",
}


def summarize(findings: List[Finding]) -> dict:
    total = len(findings)
    failed = [f for f in findings if f.status == "FAIL"]
    passed = [f for f in findings if f.status == "PASS"]
    by_severity = {}
    for f in failed:
        by_severity[f.severity] = by_severity.get(f.severity, 0) + 1
    return {
        "total_checks": total,
        "passed": len(passed),
        "failed": len(failed),
        "failed_by_severity": by_severity,
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }


def write_json(findings: List[Finding], out_path: Path) -> None:
    data = {
        "summary": summarize(findings),
        "findings": [asdict(f) for f in findings],
    }
    out_path.write_text(json.dumps(data, indent=2))


def write_csv(findings: List[Finding], out_path: Path) -> None:
    with out_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(asdict(findings[0]).keys()) if findings else
                                 ["check_id", "title", "severity", "status", "resource", "details", "remediation"])
        writer.writeheader()
        for finding in findings:
            writer.writerow(asdict(finding))


def write_html(findings: List[Finding], out_path: Path, account_label: str = "") -> None:
    summary = summarize(findings)
    sorted_findings = sorted(
        findings,
        key=lambda f: (f.status != "FAIL", SEVERITY_ORDER.get(f.severity, 9), f.check_id),
    )

    rows_html = ""
    for f in sorted_findings:
        status_class = "status-fail" if f.status == "FAIL" else "status-pass"
        rows_html += f"""
        <tr class="{status_class}">
          <td>{f.check_id}</td>
          <td>{f.title}</td>
          <td><span class="badge" style="background:{SEVERITY_COLOR.get(f.severity, '#9ca3af')}">{f.severity}</span></td>
          <td><span class="status">{f.status}</span></td>
          <td>{f.resource}</td>
          <td>{f.details}</td>
          <td>{f.remediation}</td>
        </tr>"""

    severity_chips = "".join(
        f'<div class="chip"><span class="dot" style="background:{SEVERITY_COLOR.get(sev,"#9ca3af")}"></span>{sev}: {count}</div>'
        for sev, count in sorted(summary["failed_by_severity"].items(), key=lambda kv: SEVERITY_ORDER.get(kv[0], 9))
    )

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>AWS IAM Security Audit Report</title>
<style>
  :root {{
    --bg: #0b0f19; --bg-alt: #111827; --text: #e5e7eb; --muted: #9ca3af;
    --accent: #ff9900; --border: #232a3d; --card: #161c2c; --radius: 12px;
  }}
  * {{ box-sizing: border-box; }}
  body {{ background: var(--bg); color: var(--text); font-family: -apple-system, Segoe UI, Roboto, Arial, sans-serif; margin: 0; padding: 40px 24px; }}
  .container {{ max-width: 1200px; margin: 0 auto; }}
  h1 {{ font-size: 1.8rem; margin-bottom: 4px; }}
  .subtitle {{ color: var(--muted); margin-bottom: 32px; }}
  .summary {{ display: flex; gap: 16px; flex-wrap: wrap; margin-bottom: 28px; }}
  .stat {{ background: var(--card); border: 1px solid var(--border); border-radius: var(--radius); padding: 16px 24px; min-width: 140px; }}
  .stat .num {{ font-size: 1.8rem; font-weight: 700; }}
  .stat .label {{ color: var(--muted); font-size: 0.85rem; }}
  .chips {{ display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 28px; }}
  .chip {{ display: flex; align-items: center; gap: 6px; background: var(--card); border: 1px solid var(--border); border-radius: 20px; padding: 6px 14px; font-size: 0.85rem; }}
  .dot {{ width: 8px; height: 8px; border-radius: 50%; display: inline-block; }}
  table {{ width: 100%; border-collapse: collapse; background: var(--card); border-radius: var(--radius); overflow: hidden; }}
  th, td {{ text-align: left; padding: 10px 12px; border-bottom: 1px solid var(--border); font-size: 0.85rem; vertical-align: top; }}
  th {{ background: var(--bg-alt); color: var(--muted); text-transform: uppercase; font-size: 0.72rem; letter-spacing: 0.04em; }}
  tr.status-pass td:nth-child(4) .status {{ color: #3fb950; font-weight: 600; }}
  tr.status-fail td:nth-child(4) .status {{ color: #ff4d4f; font-weight: 600; }}
  .badge {{ color: #111; padding: 2px 8px; border-radius: 6px; font-size: 0.72rem; font-weight: 700; }}
  footer {{ margin-top: 24px; color: var(--muted); font-size: 0.8rem; text-align: center; }}
</style>
</head>
<body>
  <div class="container">
    <h1>🔐 AWS IAM Security Audit Report</h1>
    <p class="subtitle">{account_label + " &middot; " if account_label else ""}Generated {summary['generated_at']}</p>

    <div class="summary">
      <div class="stat"><div class="num">{summary['total_checks']}</div><div class="label">Total checks</div></div>
      <div class="stat"><div class="num" style="color:#3fb950">{summary['passed']}</div><div class="label">Passed</div></div>
      <div class="stat"><div class="num" style="color:#ff4d4f">{summary['failed']}</div><div class="label">Failed</div></div>
    </div>

    <div class="chips">{severity_chips or '<span style="color:var(--muted)">No failed checks 🎉</span>'}</div>

    <table>
      <thead>
        <tr><th>ID</th><th>Check</th><th>Severity</th><th>Status</th><th>Resource</th><th>Details</th><th>Remediation</th></tr>
      </thead>
      <tbody>{rows_html}
      </tbody>
    </table>

    <footer>Generated by aws-iam-security-audit &middot; Based on CIS AWS Foundations Benchmark &amp; AWS IAM best practices</footer>
  </div>
</body>
</html>"""
    out_path.write_text(html)
