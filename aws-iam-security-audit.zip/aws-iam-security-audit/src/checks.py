"""
checks.py — Individual IAM security checks.

Each check function returns a Finding (or list of Findings) with a status of
PASS or FAIL, a severity, and enough detail to act on it. Checks are based on
the CIS AWS Foundations Benchmark and AWS's own IAM security best practices.
"""
import csv
import io
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import List, Optional


@dataclass
class Finding:
    check_id: str
    title: str
    severity: str  # CRITICAL | HIGH | MEDIUM | LOW | INFO
    status: str    # PASS | FAIL
    resource: str
    details: str
    remediation: str = ""


def _days_since(iso_timestamp: str) -> Optional[float]:
    """Return days elapsed since an ISO8601 timestamp, or None if not applicable."""
    if not iso_timestamp or iso_timestamp.upper() in ("N/A", "NOT_SUPPORTED", ""):
        return None
    try:
        dt = datetime.fromisoformat(iso_timestamp.replace("Z", "+00:00"))
        return (datetime.now(timezone.utc) - dt).total_seconds() / 86400
    except ValueError:
        return None


def get_credential_report(iam_client, max_wait_seconds: int = 15) -> List[dict]:
    """Generate (if needed) and fetch the IAM credential report as a list of dict rows."""
    iam_client.generate_credential_report()

    waited = 0
    while waited < max_wait_seconds:
        resp = iam_client.generate_credential_report()
        if resp.get("State") == "COMPLETE":
            break
        time.sleep(1)
        waited += 1

    report = iam_client.get_credential_report()
    csv_body = report["Content"].decode("utf-8")
    return list(csv.DictReader(io.StringIO(csv_body)))


# ---------------------------------------------------------------------------
# 1. Root account checks
# ---------------------------------------------------------------------------
def check_root_mfa(iam_client) -> Finding:
    summary = iam_client.get_account_summary()["SummaryMap"]
    enabled = summary.get("AccountMFAEnabled", 0) == 1
    return Finding(
        check_id="IAM-001",
        title="Root account has MFA enabled",
        severity="CRITICAL",
        status="PASS" if enabled else "FAIL",
        resource="root account",
        details="Root account MFA is enabled." if enabled else "Root account does NOT have MFA enabled.",
        remediation="Enable a hardware or virtual MFA device on the root account immediately.",
    )


def check_root_access_keys(cred_report: List[dict]) -> Finding:
    root_row = next((r for r in cred_report if r["user"] == "<root_account>"), None)
    has_keys = root_row and (
        root_row.get("access_key_1_active") == "true" or root_row.get("access_key_2_active") == "true"
    )
    return Finding(
        check_id="IAM-002",
        title="Root account has no active access keys",
        severity="CRITICAL",
        status="FAIL" if has_keys else "PASS",
        resource="root account",
        details="Root account has at least one active access key." if has_keys else "Root account has no active access keys.",
        remediation="Delete root access keys. Use IAM users/roles for all programmatic access instead.",
    )


def check_root_recent_usage(cred_report: List[dict], max_days: int = 30) -> Finding:
    root_row = next((r for r in cred_report if r["user"] == "<root_account>"), None)
    last_used = root_row.get("password_last_used") if root_row else None
    days = _days_since(last_used)
    used_recently = days is not None and days <= max_days
    return Finding(
        check_id="IAM-003",
        title=f"Root account not used in the last {max_days} days",
        severity="HIGH",
        status="FAIL" if used_recently else "PASS",
        resource="root account",
        details=f"Root login detected {days:.1f} day(s) ago." if used_recently else "No recent root account login detected.",
        remediation="Avoid using the root account for daily tasks; use IAM roles/users with least privilege instead.",
    )


# ---------------------------------------------------------------------------
# 2. Password policy
# ---------------------------------------------------------------------------
def check_password_policy(iam_client) -> List[Finding]:
    findings = []
    try:
        policy = iam_client.get_account_password_policy()["PasswordPolicy"]
    except iam_client.exceptions.NoSuchEntityException:
        return [Finding(
            check_id="IAM-004",
            title="Account password policy is configured",
            severity="HIGH",
            status="FAIL",
            resource="account password policy",
            details="No password policy is configured for this account.",
            remediation="Set an account password policy requiring length >=14, complexity, expiry, and reuse prevention.",
        )]

    checks = [
        ("MinimumPasswordLength", lambda v: v is not None and v >= 14, "Minimum password length is at least 14 characters"),
        ("RequireSymbols", lambda v: v is True, "Password policy requires at least one symbol"),
        ("RequireNumbers", lambda v: v is True, "Password policy requires at least one number"),
        ("RequireUppercaseCharacters", lambda v: v is True, "Password policy requires uppercase characters"),
        ("RequireLowercaseCharacters", lambda v: v is True, "Password policy requires lowercase characters"),
        ("MaxPasswordAge", lambda v: v is not None and v <= 90, "Passwords expire within 90 days"),
        ("PasswordReusePrevention", lambda v: v is not None and v >= 24, "Password reuse prevention is set (>= 24)"),
    ]

    for key, predicate, title in checks:
        value = policy.get(key)
        passed = predicate(value)
        findings.append(Finding(
            check_id=f"IAM-004-{key}",
            title=title,
            severity="MEDIUM",
            status="PASS" if passed else "FAIL",
            resource="account password policy",
            details=f"{key} = {value}",
            remediation="Update the account password policy in IAM -> Account settings.",
        ))
    return findings


# ---------------------------------------------------------------------------
# 3. IAM user checks (via credential report)
# ---------------------------------------------------------------------------
def check_users_mfa(cred_report: List[dict]) -> List[Finding]:
    findings = []
    for row in cred_report:
        if row["user"] == "<root_account>":
            continue
        if row.get("password_enabled") != "true":
            continue  # no console password, MFA not applicable
        mfa_active = row.get("mfa_active") == "true"
        findings.append(Finding(
            check_id="IAM-005",
            title="Console user has MFA enabled",
            severity="HIGH",
            status="PASS" if mfa_active else "FAIL",
            resource=f"user:{row['user']}",
            details="MFA is active." if mfa_active else "Console access enabled but MFA is NOT active.",
            remediation="Require this user to enable an MFA device before their next login.",
        ))
    return findings


def check_access_key_rotation(cred_report: List[dict], max_age_days: int = 90) -> List[Finding]:
    findings = []
    for row in cred_report:
        if row["user"] == "<root_account>":
            continue
        for key_num in ("1", "2"):
            active = row.get(f"access_key_{key_num}_active") == "true"
            if not active:
                continue
            rotated = row.get(f"access_key_{key_num}_last_rotated")
            age = _days_since(rotated)
            stale = age is not None and age > max_age_days
            findings.append(Finding(
                check_id="IAM-006",
                title=f"Access key rotated within {max_age_days} days",
                severity="MEDIUM",
                status="FAIL" if stale else "PASS",
                resource=f"user:{row['user']} (key {key_num})",
                details=f"Last rotated {age:.0f} day(s) ago." if age is not None else "Rotation date unavailable.",
                remediation="Rotate this access key and update it wherever it's used.",
            ))
    return findings


def check_unused_credentials(cred_report: List[dict], max_unused_days: int = 90) -> List[Finding]:
    findings = []
    for row in cred_report:
        if row["user"] == "<root_account>":
            continue

        if row.get("password_enabled") == "true":
            last_pw_used = row.get("password_last_used", "")
            days = _days_since(last_pw_used)
            never_used = last_pw_used.lower() in ("no_information", "n/a", "")
            unused = (days is not None and days > max_unused_days) or never_used
            if unused:
                findings.append(Finding(
                    check_id="IAM-007",
                    title=f"Console password unused for more than {max_unused_days} days",
                    severity="MEDIUM",
                    status="FAIL",
                    resource=f"user:{row['user']}",
                    details="Password never used." if never_used else f"Last used {days:.0f} day(s) ago.",
                    remediation="Disable console access for this user if it's no longer needed.",
                ))

        for key_num in ("1", "2"):
            if row.get(f"access_key_{key_num}_active") != "true":
                continue
            last_used = row.get(f"access_key_{key_num}_last_used_date", "")
            days = _days_since(last_used)
            never_used = last_used.lower() in ("n/a", "no_information", "") if last_used else True
            unused = (days is not None and days > max_unused_days) or never_used
            if unused:
                findings.append(Finding(
                    check_id="IAM-008",
                    title=f"Access key unused for more than {max_unused_days} days",
                    severity="MEDIUM",
                    status="FAIL",
                    resource=f"user:{row['user']} (key {key_num})",
                    details="Key never used." if never_used else f"Last used {days:.0f} day(s) ago.",
                    remediation="Deactivate or delete this access key if it's no longer needed.",
                ))
    return findings


# ---------------------------------------------------------------------------
# 4. IAM policy attachment checks (require list_users / policy API calls)
# ---------------------------------------------------------------------------
def check_no_inline_or_direct_admin_policies(iam_client) -> List[Finding]:
    findings = []
    paginator = iam_client.get_paginator("list_users")
    for page in paginator.paginate():
        for user in page["Users"]:
            username = user["UserName"]

            inline = iam_client.list_user_policies(UserName=username)["PolicyNames"]
            findings.append(Finding(
                check_id="IAM-009",
                title="User has no inline policies (should use groups/managed policies)",
                severity="LOW",
                status="FAIL" if inline else "PASS",
                resource=f"user:{username}",
                details=f"Inline policies: {inline}" if inline else "No inline policies attached.",
                remediation="Move permissions to a managed policy attached via a group instead of inline on the user.",
            ))

            attached = iam_client.list_attached_user_policies(UserName=username)["AttachedPolicies"]
            has_admin = any(p["PolicyName"] == "AdministratorAccess" for p in attached)
            findings.append(Finding(
                check_id="IAM-010",
                title="AdministratorAccess is not attached directly to the user",
                severity="HIGH",
                status="FAIL" if has_admin else "PASS",
                resource=f"user:{username}",
                details="AdministratorAccess attached directly to user." if has_admin else "No direct AdministratorAccess attachment.",
                remediation="Attach AdministratorAccess to a group (or use a role), not directly to an individual user.",
            ))

            groups = iam_client.list_groups_for_user(UserName=username)["Groups"]
            findings.append(Finding(
                check_id="IAM-011",
                title="User is assigned to at least one group",
                severity="LOW",
                status="PASS" if groups else "FAIL",
                resource=f"user:{username}",
                details=f"Member of {len(groups)} group(s)." if groups else "User is not a member of any group.",
                remediation="Manage this user's permissions via group membership rather than individually.",
            ))
    return findings
