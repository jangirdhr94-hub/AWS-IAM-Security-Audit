#!/usr/bin/env bash
#
# run_audit.sh — Convenience wrapper to run the IAM security audit locally.
#
# Usage:
#   ./scripts/run_audit.sh [aws-profile-name]
#
set -euo pipefail

PROFILE="${1:-default}"
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "==> Installing dependencies"
pip3 install -r "$ROOT_DIR/requirements.txt" --quiet --break-system-packages 2>/dev/null || \
  pip3 install -r "$ROOT_DIR/requirements.txt" --quiet

echo "==> Running IAM security audit using AWS profile: $PROFILE"
python3 "$ROOT_DIR/src/iam_audit.py" \
  --profile "$PROFILE" \
  --output-dir "$ROOT_DIR/reports"

echo ""
echo "✅ Done. Open reports/iam-audit-report.html in your browser to view the results."
