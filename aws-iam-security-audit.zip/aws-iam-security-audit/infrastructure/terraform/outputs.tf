output "audit_role_arn" {
  description = "ARN of the least-privilege IAM audit role — use this in GitHub Actions or with 'aws sts assume-role'"
  value       = aws_iam_role.audit.arn
}

output "audit_policy_arn" {
  description = "ARN of the read-only audit policy attached to the role"
  value       = aws_iam_policy.audit_permissions.arn
}
