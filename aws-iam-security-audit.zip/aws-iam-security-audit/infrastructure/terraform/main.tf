# ---------------------------------------------------------------------------
# GitHub Actions OIDC provider (optional — skip if your account already has one;
# an AWS account can only have a single OIDC provider per URL, so if you get a
# "provider already exists" error, set enable_github_oidc = false and instead
# reference your existing provider's ARN in the trust policy below manually).
# ---------------------------------------------------------------------------
resource "aws_iam_openid_connect_provider" "github" {
  count = var.enable_github_oidc ? 1 : 0

  url             = "https://token.actions.githubusercontent.com"
  client_id_list  = ["sts.amazonaws.com"]
  thumbprint_list = ["6938fd4d98bab03faadb97b34396831e3780aea1"]

  tags = var.tags
}

# ---------------------------------------------------------------------------
# Trust policy: allow GitHub Actions (scoped to one repo) and/or specific
# AWS account IDs to assume this role.
# ---------------------------------------------------------------------------
data "aws_iam_policy_document" "trust" {
  dynamic "statement" {
    for_each = var.enable_github_oidc ? [1] : []
    content {
      effect  = "Allow"
      actions = ["sts:AssumeRoleWithWebIdentity"]

      principals {
        type        = "Federated"
        identifiers = [aws_iam_openid_connect_provider.github[0].arn]
      }

      condition {
        test     = "StringEquals"
        variable = "token.actions.githubusercontent.com:aud"
        values   = ["sts.amazonaws.com"]
      }

      condition {
        test     = "StringLike"
        variable = "token.actions.githubusercontent.com:sub"
        values   = ["repo:${var.github_org_repo}:*"]
      }
    }
  }

  dynamic "statement" {
    for_each = length(var.trusted_account_ids) > 0 ? [1] : []
    content {
      effect  = "Allow"
      actions = ["sts:AssumeRole"]

      principals {
        type        = "AWS"
        identifiers = [for id in var.trusted_account_ids : "arn:aws:iam::${id}:root"]
      }
    }
  }
}

resource "aws_iam_role" "audit" {
  name               = var.role_name
  assume_role_policy = data.aws_iam_policy_document.trust.json
  tags               = var.tags
}

# ---------------------------------------------------------------------------
# Least-privilege policy — exactly the read-only IAM/STS calls this tool needs.
# No write, create, or delete permissions of any kind.
# ---------------------------------------------------------------------------
data "aws_iam_policy_document" "audit_permissions" {
  statement {
    sid    = "IAMReadOnlyForAudit"
    effect = "Allow"
    actions = [
      "iam:GenerateCredentialReport",
      "iam:GetCredentialReport",
      "iam:GetAccountSummary",
      "iam:GetAccountPasswordPolicy",
      "iam:ListUsers",
      "iam:ListUserPolicies",
      "iam:ListAttachedUserPolicies",
      "iam:ListGroupsForUser",
      "iam:ListMFADevices",
      "iam:ListVirtualMFADevices",
      "iam:ListAccessKeys",
      "iam:GetUser",
    ]
    resources = ["*"]
  }

  statement {
    sid       = "AllowCallerIdentity"
    effect    = "Allow"
    actions   = ["sts:GetCallerIdentity"]
    resources = ["*"]
  }
}

resource "aws_iam_policy" "audit_permissions" {
  name        = "${var.role_name}-policy"
  description = "Least-privilege read-only permissions for the IAM security audit tool"
  policy      = data.aws_iam_policy_document.audit_permissions.json
  tags        = var.tags
}

resource "aws_iam_role_policy_attachment" "audit" {
  role       = aws_iam_role.audit.name
  policy_arn = aws_iam_policy.audit_permissions.arn
}
