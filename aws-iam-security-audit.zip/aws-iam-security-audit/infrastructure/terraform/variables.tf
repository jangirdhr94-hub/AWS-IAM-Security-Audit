variable "aws_region" {
  description = "AWS region (IAM is global, but boto3/terraform still require one)"
  type        = string
  default     = "us-east-1"
}

variable "role_name" {
  description = "Name of the IAM read-only audit role"
  type        = string
  default     = "iam-security-audit-role"
}

variable "enable_github_oidc" {
  description = "Whether to create a GitHub Actions OIDC trust relationship for this role"
  type        = bool
  default     = false
}

variable "github_org_repo" {
  description = "GitHub 'org/repo' allowed to assume this role via OIDC, e.g. 'yourname/aws-iam-security-audit'"
  type        = string
  default     = ""
}

variable "trusted_account_ids" {
  description = "AWS account IDs (besides GitHub OIDC) allowed to assume this role, for local/manual audits"
  type        = list(string)
  default     = []
}

variable "tags" {
  description = "Common resource tags"
  type        = map(string)
  default = {
    Project = "aws-iam-security-audit"
  }
}
