# 🔐 AWS IAM Security Audit

A complete, ready-to-use tool that audits an AWS account's IAM configuration against
the **CIS AWS Foundations Benchmark** and AWS's own IAM security best practices —
then produces a styled HTML report (plus JSON and CSV) you can review, share, or
wire into CI as a recurring compliance check.

![Sample report](sample-report/sample-report.html)
*(open `sample-report/sample-report.html` in a browser to see an example report with sample findings)*

---

## 📋 Table of Contents

- [Overview](#-overview)
- [What it checks](#-what-it-checks)
- [Project Structure](#-project-structure)
- [Prerequisites](#-prerequisites)
- [Quick Start (local)](#-quick-start-local)
- [Provisioning a least-privilege audit role](#-provisioning-a-least-privilege-audit-role)
- [Running audits automatically in CI](#-running-audits-automatically-in-ci)
- [Understanding the report](#-understanding-the-report)
- [Extending the tool](#-extending-the-tool)
- [License](#-license)

---

## 📖 Overview

Misconfigured IAM is one of the most common root causes of AWS security incidents —
root accounts without MFA, unrotated access keys, admin permissions attached
directly to individual users, and stale credentials that nobody remembers to
disable. This tool automates checking for exactly those issues.

It uses **read-only** IAM/STS API calls only (never modifies anything in your
account), and outputs:

- A **styled HTML report** you can open in any browser
- A **JSON report** for programmatic consumption
- A **CSV report** for spreadsheets or ticketing system imports

## ✅ What it checks

| # | Check | Severity | Basis |
|---|---|---|---|
| IAM-001 | Root account has MFA enabled | Critical | CIS 1.5 |
| IAM-002 | Root account has no active access keys | Critical | CIS 1.4 |
| IAM-003 | Root account not used recently | High | CIS 1.7 |
| IAM-004 | Account password policy meets complexity/length/expiry/reuse rules | Medium | CIS 1.8–1.11 |
| IAM-005 | Every console user has MFA enabled | High | CIS 1.2 |
| IAM-006 | Active access keys rotated within 90 days | Medium | CIS 1.14 |
| IAM-007 | No console passwords unused for 90+ days | Medium | CIS 1.12 |
| IAM-008 | No access keys unused for 90+ days | Medium | CIS 1.13 |
| IAM-009 | Users have no inline policies (use managed policies via groups) | Low | AWS best practice |
| IAM-010 | `AdministratorAccess` is never attached directly to a user | High | AWS best practice |
| IAM-011 | Every user belongs to at least one group | Low | AWS best practice |

All thresholds (max key age, max unused days) are configurable via CLI flags.

## 📂 Project Structure

```
aws-iam-security-audit/
├── src/
│   ├── checks.py               # All individual security checks
│   ├── report.py                # JSON/CSV/HTML report generation
│   └── iam_audit.py             # CLI entry point — orchestrates everything
├── infrastructure/
│   └── terraform/
│       ├── provider.tf
│       ├── variables.tf
│       ├── main.tf              # Least-privilege audit role + optional GitHub OIDC
│       ├── outputs.tf
│       └── terraform.tfvars.example
├── scripts/
│   └── run_audit.sh             # Convenience wrapper for local runs
├── sample-report/
│   ├── sample-report.html       # Example output with sample findings
│   └── sample-report.json
├── .github/workflows/scheduled-audit.yml   # Weekly automated audit via OIDC
├── requirements.txt
├── .gitignore
├── LICENSE
└── README.md
```

## ✅ Prerequisites

- Python 3.9+
- An AWS account and credentials with (at minimum) read-only IAM access
- [AWS CLI](https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html) configured (`aws configure`), or an assumable role
- (Optional, for the least-privilege role) [Terraform](https://developer.hashicorp.com/terraform/install) `>= 1.5.0`

---

## 🚀 Quick Start (local)

Using your own AWS credentials (e.g. an admin profile, for a first test run):

```bash
git clone https://github.com/<your-username>/aws-iam-security-audit.git
cd aws-iam-security-audit

pip install -r requirements.txt

python src/iam_audit.py --profile default --output-dir ./reports
```

Then open `reports/iam-audit-report.html` in your browser.

Or use the convenience script:

```bash
./scripts/run_audit.sh my-aws-profile
```

**CLI options:**

| Flag | Default | Description |
|---|---|---|
| `--profile` | none (default credentials) | AWS CLI profile to use |
| `--region` | `us-east-1` | Region (IAM is global, but boto3 requires one) |
| `--output-dir` | `./reports` | Where to write the JSON/CSV/HTML reports |
| `--max-key-age` | `90` | Days before an active access key is flagged as stale |
| `--max-unused-days` | `90` | Days of inactivity before a credential is flagged as unused |
| `--fail-on-critical` | off | Exit with a non-zero status if any CRITICAL check fails (for CI) |

---

## 🔒 Provisioning a least-privilege audit role

Running this with your admin credentials works, but for repeated or automated
audits you should use a role that can **only read** IAM data — nothing else.
Terraform in `infrastructure/terraform/` creates exactly that:

```bash
cd infrastructure/terraform
cp terraform.tfvars.example terraform.tfvars
# edit terraform.tfvars — set enable_github_oidc = true if using GitHub Actions

terraform init
terraform apply
```

This creates an IAM role with a policy allowing **only**:
`iam:GenerateCredentialReport`, `iam:GetCredentialReport`, `iam:GetAccountSummary`,
`iam:GetAccountPasswordPolicy`, `iam:List*` (users/policies/groups/MFA/keys),
`iam:GetUser`, and `sts:GetCallerIdentity`. No write, create, or delete
permissions of any kind.

To run the audit locally using this role:

```bash
aws sts assume-role \
  --role-arn "$(terraform -chdir=infrastructure/terraform output -raw audit_role_arn)" \
  --role-session-name iam-audit
# export the returned AccessKeyId / SecretAccessKey / SessionToken, then:
python src/iam_audit.py --output-dir ./reports
```

---

## 🔄 Running audits automatically in CI

`.github/workflows/scheduled-audit.yml` runs the audit every **Monday at 06:00 UTC**
(and on-demand via "Run workflow"), using **GitHub OIDC** to assume the audit role —
no long-lived AWS keys are ever stored in GitHub.

Setup:

1. In `terraform.tfvars`, set `enable_github_oidc = true` and
   `github_org_repo = "your-username/aws-iam-security-audit"`, then `terraform apply`.
2. Add one repository secret (Settings → Secrets and variables → Actions):

   | Secret | Value |
   |---|---|
   | `AWS_AUDIT_ROLE_ARN` | Output of `terraform output audit_role_arn` |

3. Reports are uploaded as a workflow artifact after each run (kept 90 days), and
   the job fails the build if any **CRITICAL** finding is detected (via
   `--fail-on-critical`) so you can wire it into branch protection or alerts.

---

## 📊 Understanding the report

The HTML report groups findings with:

- **Summary cards** — total checks, passed, failed
- **Severity chips** — count of failures per severity (Critical/High/Medium/Low)
- **Findings table** — sorted failures-first, most severe first, each with the
  affected resource, what was found, and a concrete remediation step

Treat **CRITICAL** and **HIGH** findings as immediate action items (root account
hygiene, missing MFA, directly-attached admin access). **MEDIUM/LOW** findings are
good hygiene items to work through over time (key rotation, unused credentials,
inline policies).

## 🧩 Extending the tool

Adding a new check is just a new function in `src/checks.py` that returns one or
more `Finding` objects, then a call to it from `run_audit()` in `src/iam_audit.py`.
Some natural additions:

- Cross-reference IAM Access Analyzer findings
- Check for unused IAM roles (via `GetServiceLastAccessedDetails`)
- Check for wildcard (`"Action": "*", "Resource": "*"`) statements in customer-
  managed policies
- Multi-account support via AWS Organizations + `sts:AssumeRole` fan-out

## 📄 License

This project is licensed under the [MIT License](LICENSE) — feel free to fork,
modify, and use it for your own AWS security work or portfolio projects.
